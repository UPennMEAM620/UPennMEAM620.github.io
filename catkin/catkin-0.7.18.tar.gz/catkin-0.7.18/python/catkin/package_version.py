# for backward compatibility
from catkin_pkg.package_version import *  # noqa
